<?php
/**
 * Index template (blog/posts)
 */
pixflow_generate_page('blog');
