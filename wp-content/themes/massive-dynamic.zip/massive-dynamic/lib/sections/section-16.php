<?php
$section_params = array(
	'row_type' => "none"
, 'type_width' =>'full_size'
,'row_fit_to_height'=>'no'
,'box_size_states'=>'content_box_size'
,'el_class'=>''
,'row_vertical_align'=>'no'
,'row_equal_column_heigh'=>'no'
,'row_content_vertical_align'=>'0'
,'row_padding_top'=>'204'
,'row_padding_bottom'=>'204'
,'row_padding_right'=>'0'
,'row_padding_left'=>'0'
,'row_margin_top'=>'0'
,'row_margin_bottom'=>'0'
,'background_color'=>'rgb(245, 245, 245)'
,'row_webm_url'=>''
,'row_mp4_url'=>''
,'background_color_image'=>'rgba(0, 0, 0, 0.2)'
,'row_image_position'=>'default'
,'row_bg_image_size_tab_image'=>'cover'
,'row_bg_repeat_image_gp='=>'no'
,'first_color'=>'#000'
,'second_color'=>'#000'
,'row_gradient_color'=>'pixflow_base64eyJjb2xvcjEiOiIjZmZmIiwiY29sb3IyIjoicmdiYSgyNTUsMjU1LDI1NSwwKSIsImNvbG9yMVBvcyI6IjAuMDAiLCJjb2xvcjJQb3MiOiIxMDAuMDAiLCJhbmdsZSI6MH0='
,'row_image_position_gradient'=>'fit'
,' row_bg_image_size_tab_gradient'=>'cover'
,'row_bg_repeat_gradient_gp'=>'no'
,'row_inner_shadow'=>'no'
,'row_sloped_edge'=>'no'
,'row_slope_edge_position'=>'top'
,'row_sloped_edge_color'=>'#000'
,'row_sloped_edge_angle'=>'-3'
,'parallax_status'=>'no'
,'parallax_speed'=>'1'
,'align' => 'no'


, 'content' => '[vc_column el_class="" width="4/12" border_color="rgba(0,0,0,1)" border_style="solid" background_color="rgba(0,0,0,0)" margin_top="0" margin_right="0" margin_bottom="0" margin_left="0" padding_top="0" padding_right="10" padding_bottom="0" padding_left="0" border_top_width="0" border_right_width="0" border_bottom_width="0" border_left_width="0" css="{border-color:rgba(0,0,0,1);border-style:solid;background-color:rgba(0,0,0,0);background-size:;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:10px;padding-bottom:0px;padding-left:0px;border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;}" md_laptop_visibility="yes" md_tablet_portrait_visibility="yes" md_tablet_landscape_visibility="yes" md_tablet_portrait_width="12" md_mobile_portrait_visibility="yes" md_mobile_landscape_visibility="yes"][md_textbox textbox_icon="icon-layers4" textbox_title="Easy Interface" textbox_heading="h6" textbox_description="Any business, big or small, should have the online presence expansion as a key part of their." textbox_bg_color="#FFF" textbox_icon_color="rgb(0, 202, 142)" textbox_content_color="rgb(52, 52, 52)" md_textbox_animation="yes" md_textbox_animation_type="fade" md_textbox_animation_speed="800" md_textbox_animation_delay="0.4" md_textbox_animation_position="bottom" md_textbox_animation_show="once" md_textbox_animation_easing="Power4.easeOut" md_textbox_parallax_speed="1"][/md_textbox][/vc_column][vc_column el_class="" width="4/12" border_color="rgba(0,0,0,1)" border_style="solid" background_color="rgba(0,0,0,0)" margin_top="0" margin_right="0" margin_bottom="0" margin_left="0" padding_top="0" padding_right="5" padding_bottom="0" padding_left="0" border_top_width="0" border_right_width="0" border_bottom_width="0" border_left_width="0" css="{border-color:rgba(0,0,0,1);border-style:solid;background-color:rgba(0,0,0,0);background-size:;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:5px;padding-bottom:0px;padding-left:0px!important;border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;}" md_laptop_visibility="yes" md_tablet_portrait_visibility="yes" md_tablet_landscape_visibility="yes" md_mobile_portrait_visibility="yes" md_mobile_landscape_visibility="yes" md_tablet_portrait_width="12"][md_textbox textbox_icon="icon-air-play" textbox_title="True Presentation" textbox_heading="h6" textbox_description="Any business, big or small, should have the online presence expansion as a key part of their." textbox_bg_color="#FFF" textbox_icon_color="rgb(65, 135, 235)" textbox_content_color="rgb(52, 52, 52)" md_textbox_animation="yes" md_textbox_animation_type="fade" md_textbox_animation_speed="800" md_textbox_animation_delay="0.5" md_textbox_animation_position="bottom" md_textbox_animation_show="once" md_textbox_animation_easing="Power4.easeOut" md_textbox_parallax_speed="1"][/md_textbox][/vc_column][vc_column el_class="" width="4/12" border_color="rgba(0,0,0,1)" border_style="solid" background_color="rgba(0,0,0,0)" margin_top="0" margin_right="0" margin_bottom="0" margin_left="0" padding_top="0" padding_right="0" padding_bottom="0" padding_left="10" border_top_width="0" border_right_width="0" border_bottom_width="0" border_left_width="0" css="{border-color:rgba(0,0,0,1);border-style:solid;background-color:rgba(0,0,0,0);background-size:;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:10px;border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;}" md_laptop_visibility="yes" md_tablet_portrait_visibility="yes" md_tablet_landscape_visibility="yes" md_tablet_portrait_width="12" md_mobile_portrait_visibility="yes" md_mobile_landscape_visibility="yes"][md_textbox textbox_icon="icon-image" textbox_title="Flexible Charts " textbox_description="Any business, big or small, should have the online presence expansion as a key part of their." textbox_heading="h6" textbox_bg_color="#FFF" textbox_icon_color="rgb(213, 33, 239)" textbox_content_color="rgb(52, 52, 52)" md_textbox_animation="yes" md_textbox_animation_type="fade" md_textbox_animation_speed="800" md_textbox_animation_delay="0.6" md_textbox_animation_position="bottom" md_textbox_animation_show="once" md_textbox_animation_easing="Power4.easeOut" md_textbox_parallax_speed="1"][/md_textbox][/vc_column]'
);





