<?php
$section_params = array(
	'type_width'=>'full_size'
,'box_size_states'=>'content_box_size'
,'el_class'=>''
,'row_fit_to_height' => 'no'
,'row_vertical_align'=>'no'
,'row_equal_column_heigh'=>'no'
,'row_content_vertical_align'=>'0'
,'row_type'=>'image'
,'background_color'=>'rgba(255,255,255,1)'
,'row_webm_url'=>''
,'row_mp4_url'=>''
,'background_color_image'=>'rgba(0, 0, 0, 0)'
,'first_color'=>'#000'
,'second_color'=>'#000'
,'row_gradient_color'=>'pixflow_base64eyJjb2xvcjEiOiIjZmZmIiwiY29sb3IyIjoicmdiYSgyNTUsMjU1LDI1NSwwKSIsImNvbG9yMVBvcyI6IjAuMDAiLCJjb2xvcjJQb3MiOiIxMDAuMDAiLCJhbmdsZSI6MH0'
,'row_image'=>'http://theme.pixflow.net/massive-dynamic/section/section-30/sec30-bak.jpg'
,'row_image_position_gradient'=>'fit'
,'row_image_position'=>'default'
,'row_bg_image_size_tab_image'=>'cover'
,'row_bg_image_size_tab_gradient'=>'cover'
,'row_bg_repeat_image_gp'=>'no'
,'row_bg_repeat_gradient_gp'=>'no'
,'row_section_id'=>'subscribe-section'
,'row_padding_top'=>'120'
,'row_padding_bottom'=>'120'
,'row_bg_image_size_tab_gradient'=>'cover'
,'row_padding_right'=>'0'
,'row_padding_left'=>'0'
,'row_margin_top'=>'0'
,'row_margin_bottom'=>'0'
,'row_inner_shadow'=>'no'
,'row_sloped_edge'=>'no'
,'row_slope_edge_position'=>'top'
,'row_sloped_edge_color'=>'#000'
,'row_sloped_edge_angle'=>'-3'
,'parallax_status'=>'yes'
,'parallax_speed'=>'5'


, 'content' => '[vc_column][md_modern_subscribe subscribe_title="Sign Up To Our Newsletter" subscribe_desc="To get the latest news from us please subscribe your email.we promise worthy news with no spam." subscribe_shadow="yes" subscribe_textcolor="#000" subscribe_bgcolor="#fff" subscribe_image="http://theme.pixflow.net/massive-dynamic/section/section-30/section30-1.jpg" md_modern_subscribe_animation="yes" md_modern_subscribe_animation_speed="800" md_modern_subscribe_animation_delay="0.4" md_modern_subscribe_animation_position="bottom" md_modern_subscribe_animation_show="scroll" md_modern_subscribe_animation_easing="Power4.easeOut"][/md_modern_subscribe][/vc_column]
'
);







