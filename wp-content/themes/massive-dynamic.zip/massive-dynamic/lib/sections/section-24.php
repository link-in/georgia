<?php
$section_params = array(
	'row_type' => "image"
, 'type_width' =>'full_size'
,'row_fit_to_height'=>'no'
,'box_size_states'=>'content_box_size'
,'el_class'=>''
,'row_vertical_align'=>'no'
,'row_equal_column_heigh'=>'no'
,'row_content_vertical_align'=>'0'
,'row_padding_top'=>'180'
,'row_padding_bottom'=>'130'
,'row_padding_right'=>'0'
,'row_padding_left'=>'0'
,'row_margin_top'=>'0'
,'row_margin_bottom'=>'0'
,'background_color'=>'rgba(255,255,255,1)'
,'row_webm_url'=>''
,'row_mp4_url'=>''
,'background_color_image'=>'rgba(0, 0, 0, 0.14)'
,'row_image_position'=>'default'
,'row_bg_image_size_tab_image'=>'cover'
,'row_bg_repeat_image_gp='=>'yes'
,'first_color'=>'#000'
,'second_color'=>'#000'
,'row_gradient_color'=>'pixflow_base64eyJjb2xvcjEiOiIjZmZmIiwiY29sb3IyIjoicmdiYSgyNTUsMjU1LDI1NSwwKSIsImNvbG9yMVBvcyI6IjAuMDAiLCJjb2xvcjJQb3MiOiIxMDAuMDAiLCJhbmdsZSI6MH0='
,'row_image_position_gradient'=>'fit'
,' row_bg_image_size_tab_gradient'=>'cover'
,'row_bg_repeat_gradient_gp'=>'no'
,'row_inner_shadow'=>'no'
,'row_sloped_edge'=>'no'
,'row_slope_edge_position'=>'top'
,'row_sloped_edge_color'=>'#000'
,'row_sloped_edge_angle'=>'-3'
,'parallax_status'=>'yes'
,'parallax_speed'=>'3'
, 'row_image' => 'http://theme.pixflow.net/massive-dynamic/section/section-24/section24-1.jpg'

, 'content' => '[vc_column width="1/3" css=".vc_custom_1454843617187{margin-bottom: 30px !important;padding-right:22px!important;}"  padding_right="22"][md_fancy_text fancy_text_title="Concept" fancy_text_heading="h4" fancy_text_text="Massive Dynamic has over 10 years of experience in Design. We take pride in delivering Intelligent Designs and Engaging Experiences for clients all over the World." fancy_text_bg_type="text" fancy_text_icon="icon-MusicalNote" fancy_text_bg_text="01" fancy_text_title_color="rgb(255, 255, 255)" fancy_text_text_color="rgb(189, 189, 189)" fancy_text_bg_color="rgb(91, 91, 91)" md_fancy_text_animation="yes" md_fancy_text_animation_speed="800" md_fancy_text_animation_delay="0.4" md_fancy_text_animation_position="left" md_fancy_text_animation_show="once" md_fancy_text_animation_easing="Power4.easeOut" align="left"][/md_fancy_text][/vc_column][vc_column width="1/3" css=".vc_custom_1454843628686{margin-bottom: 30px !important;padding-right:23px!important;}"  padding_right="23"][md_fancy_text fancy_text_title="Design" fancy_text_heading="h4" fancy_text_text="Massive Dynamic has over 10 years of experience in Design. We take pride in delivering Intelligent Designs and Engaging Experiences for clients all over the World." fancy_text_bg_type="text" fancy_text_icon="icon-MusicalNote" fancy_text_bg_text="02" fancy_text_title_color="rgb(255, 255, 255)" fancy_text_text_color="rgb(189, 189, 189)" fancy_text_bg_color="rgb(91, 91, 91)" md_fancy_text_animation="yes" md_fancy_text_animation_speed="800" md_fancy_text_animation_delay="0.5" md_fancy_text_animation_position="left" md_fancy_text_animation_show="once" md_fancy_text_animation_easing="Power4.easeOut"][/md_fancy_text][/vc_column][vc_column width="1/3"][md_fancy_text fancy_text_title="Performance" fancy_text_heading="h4" fancy_text_text="Massive Dynamic has over 10 years of experience in Design. We take pride in delivering Intelligent Designs and Engaging Experiences for clients all over the World." fancy_text_bg_type="text" fancy_text_icon="icon-MusicalNote" fancy_text_bg_text="03" fancy_text_title_color="rgb(255, 255, 255)" fancy_text_text_color="rgb(189, 189, 189)" fancy_text_bg_color="rgb(91, 91, 91)" md_fancy_text_animation="yes" md_fancy_text_animation_speed="800" md_fancy_text_animation_delay="0.6" md_fancy_text_animation_position="left" md_fancy_text_animation_show="once" md_fancy_text_animation_easing="Power4.easeOut"][/md_fancy_text][/vc_column]'
);





